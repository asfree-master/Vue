<template>
  <div class="hello">
      <h1>이벤트실습1</h1>
      값1<input type="text" v-model="num1"><br>
      값2<input type="text" v-model="num2"><br>
      <button @click="sum($event)">+</button>
      <button @click="sum($event)">-</button>
      <button @click="sum($event)">+</button>
      <button @click="sum($event)">/</button><br>
      결과값: {{total}}      
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   data:function(){
       return {
           num1:"",
           num2:"",
           total:""
       }
   },
   methods:{
       sum:function(e){
          // this.total= Number.parseInt(this.num1)+ Number.parseInt(this.num2);
        var action=e.target.innerText;
        switch(action){ //주의 
            case '+':
                this.total= Number.parseInt(this.num1)+ Number.parseInt(this.num2);
                break;
            case '-':
                this.total= Number.parseInt(this.num1)- Number.parseInt(this.num2);
                break;
            case '*':
                this.total= Number.parseInt(this.num1)* Number.parseInt(this.num2);
                break;
            case '/':
                this.total= Number.parseInt(this.num1)/ Number.parseInt(this.num2);
                break;
            default:
                this.total="잘못된 값입력";
        }
       }
   }
}
</script>

<style>

</style>