<template>
  <div class="hello">
      값:{{num}}<br>
      {{xxx()}}{{xxx()}}
      {{yyy}}{{yyy}} <!--computed 함수: 속성명으로 호출 -->
      {{change()}}
      
  </div>
</template>
<script>

export default {
data:function(){
    return{
        num:10
    }
},
//1. methods함수는 기본적으로 매번 호출됨
//2. data속성값이 변경되면 자동으로 호출됨
methods:{
    xxx:function(){
       // console.log("xxx호출됨");
        console.log("xxx 호출됨", this.num);
    },
    change:function(){
        this.num=20;
        //return "";
    }
},
//1. computed함수는 기본적으로 한번만 호출됨(캐싱), 속성으로 사용함{{yyy}}
//2. data속성이 변경되면 자동으로 매번 호출됨

computed:{
    yyy:function(){
        console.log("yyy호출됨", this.num);
        return "";
    },
    
}
}
</script>

<style>

</style>