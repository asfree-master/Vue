<template>
  <div id="app">
   <Speech-box class="sanders" :headerText="A.header" :footerText="A.footer">
     <!--slot영역 -->
      <div>
         <p>{{A.message}}</p>
      </div>
     <!--slot영역 -->
   </Speech-box>
  </div>
</template>

<script>
import SpeechBox from './components/SpeechBox.vue'

export default {
  name: 'App',
  components: {
    SpeechBox //SpeechBox component사용
  },
  data:function(){
    return{
      A:{
        header:"오바마 대통령 고별 연설문",
        footer:"2017/01/01",
        message:"저의 동료 여러분...."
      },
      B:{
        header:"버니 센더슨 경선 패배 연설문",
        footer:"2016/07/25",
        message:"감사합니다. 여러분...."
      },
    }
  }
}
</script>

<style>
.sanders { background-color:antiquewhite; } 
.sanders-content { font-family: 굴림; text-decoration: underline; } 
</style>
