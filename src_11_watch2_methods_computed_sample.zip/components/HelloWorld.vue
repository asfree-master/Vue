<template>
  <div class="hello">
      <h1>watch속성</h1>
      값: <input type="text" v-model="num"/>      
      <button v-on:click="xxx">method</button><br>
      {{xxx()}}{{yyy}}
  </div>
</template>
<script>
export default {
data:function(){
    return { num:10 }
},
 // 1. watch 속성의 함수명은 반드시 data 속성명과 일치해야 된다.
  // 2. methods 및 computed 함수도 data 속성이 변경되면 자동으로 호출되지만,
  //  반드시 명시적으로 함수명을 지정한 경우에만 해당된다.
  //  하지만 watch는 명시적으로 호출하지 않아도 자동으로 호출된다.
watch:{
    num:function(){//함수명과 data의 변수명이 일치되어야함.
        console.log("watch====",this.num);
    }
},
methods:{
    xxx:function(){
        console.log("methods====", this.num);
    }
},
computed:{
    yyy: function(){
        console.log("computed====", this.num);
        return "";
    }
}
}
</script>

<style>

</style>