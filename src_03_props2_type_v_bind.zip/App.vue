<template>
<div id="app">
   <!-- 
        my-address 같은 케밥 표기법으로 넘기면 
        받는 쪽에서는 반드시 카멜표기법을 사용해야 된다.
    -->
    <!-- https://kr.vuejs.org/v2/guide/components-props.html#Passing-a-Number -->
    <!-- 배열, 숫자 , boolean, 객체는 반드시 v-bind를 사용해야 함 -->
  <HelloWorld
    username="홍길동" age="20" my-address="서울"
    isMarried  v-bind:isMarried2="false" 
    v-bind:phones="[100,200,300]"
    v-bind:author="{
      name:'이순신',
      company:'Vreidian Dynamic'
    }"

  
  />
</div>
</template>

<script>
import HelloWorld from './components/HelloWorld';

export default {
  name: 'App',
components:{
  HelloWorld,
}
}
</script>

<style>

</style>
