<template>
    <div id="hello">
        <h1> {{username}}, {{age}}, {{myAddress}} </h1>
        <h1> {{isMarried}}, {{isMarried2}}, {{phone}} </h1>
        <h1>  {{author.name}},  {{author.company}}</h1>
    </div>
  
</template>

<script>
export default {
 name: "Hello",
 //https://kr.vuejs.org/v2/guide/components-props.html 
 props:[
     'username',
     'age',
     'myAddress',
     'isMarried',
     'isMarried2',
     'phone',
     'author'
 ]
}
</script>

<style>

</style>