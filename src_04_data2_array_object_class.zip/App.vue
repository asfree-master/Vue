<template>
  <div id="app">
   이름:{{x}}<br>
   나이:{{y}}<br>
   z:{{z}}<br>
  이메일 k:{{k.aa}}, {{k.bb}}<br>
   person:{{p.getUsername()}}, {{p.getAge()}}<br>
    <HelloWorld username="홍길동" age="20"/>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'
import {Person}from './components/Person';

export default {
  name: 'App',
  components: {
    HelloWorld
  },
  //상태를 저장하는 data옵션은 반드시 함수로 작성한다.
data:function(){
  return {
    x:"홍길동", 
    y:40,
    z:[10,20,30],
    k:{aa:"hong", bb:30},
    p:new Person("aaa", 20)

  }
}
  // data: ()=>{ return{
  //     x:"홍길동",
  //     y:"40",
  //   }    
  // }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
