<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
    이름: <input type="text" v-model="username" >
    <span v-if="username.length<3">이름은 3글자 이상입니다.</span><br>
    나이: <input type="text" v-model.number="age" >
     <span v-if="age < 10 || age >120">나이는 10세이상, 120세 이하만 가능합니다.</span><br> 
    {{username.length}} {{age.toFixed(4)}}
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props:{
    msg:String
  },
  //data는 함수로 작성
  data:function(){
    return {
      username:"홍길동",
      age:10
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
