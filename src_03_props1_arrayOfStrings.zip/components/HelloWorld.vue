<template>
    <div id="hello">
        <h1> {{username}}, {{age}}, {{myAddress}}</h1>
    </div>
  
</template>

<script>
export default {
 name:"Hello",
 //https://kr.vuejs.org/v2/guide/components-props.html 
 props:["username", "age", "myAddress"] 
}
</script>

<style>

</style>