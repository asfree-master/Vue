<template>
  <div id="app">
    <!--my-address같은 케밥 표기법으로 넘기면 
    받는쪽은 반드시 카멜표기법을 사용해야 함 -->
    <HelloWorld  username="홍길동" age="20" my-address="서울" />
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld';

export default {
  name: 'App',
  components: {
    HelloWorld,
  }
}
</script>

<style>

</style>
