<template>
  <div class="hello">
    <h1>이벤트버스실습</h1>
    <button v-on:click="x">HelloWorl2로 요청</button>
  </div>
</template>

<script>
import eventBus from "./EventBus.vue";
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  methods:{
    x:function(){
      eventBus.$emit("xyz");
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
