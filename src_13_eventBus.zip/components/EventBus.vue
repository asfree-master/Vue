<template>
  
</template>

<script>
import Vue from "vue";
var eventBus= new Vue();
export default eventBus; //eventBus생성
</script>

<style>

</style>