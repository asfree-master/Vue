<template>
  <div class="hello2">
      </div>
</template>

<script>
import eventBus from "./EventBus.vue";
export default {
    name:"HelloWorld2",
   //emit처리
   created:function(){
       eventBus.$on('xyz', this.handleEvent);
   },
   methods:{
       handleEvent:function(x,y){
           console.log("emit자료", x, "\t",y);
       }
   }
}
</script>

<style>

</style>