<template>
  <div class="hello">
    <h1>{{mesg}}</h1>
    mesg: <input type="text" v-model="mesg"><br>
    mesg: <input type="text" v-model="mesg"><br>
    v-bind:mesg: <input type="text" v-bind:value="mesg"><br>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  //data옵션은 function을 사용
  data: function(){
    return {
      mesg:"홍길동"
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color:red;
}
</style>
