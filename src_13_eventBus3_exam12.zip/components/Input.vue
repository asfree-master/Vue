<template>
  <div class="hello">
    <div>
        <input type="text" v-on:keyup.enter="add" v-model="mesg">
    </div>
  </div>
</template>

<script>
import eventBus from "./EventBus.vue";
export default {
    name:"input",
    data:function(){
        return {
            mesg:""
        }
    },
    methods:{
        add:function(){
            eventBus.$emit("xyz",this.mesg);
            this.mesg="";
        }
    }
}
</script>

<style>

</style>