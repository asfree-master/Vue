<template>
  <div class="hello" >
      <ul v-for="(a, idx) in toDoList" :key="idx">
        <li>{{a}}<button v-on:click="del(idx)" >삭제</button></li>
    </ul>
  </div>
</template>

<script>
import eventBus from './EventBus.vue'
export default {
name: "List",
data: function(){
    return{
        toDoList:[]
    }
},
//emit의 처리
created:function(){
    eventBus.$on("xyz", this.add);
},
methods:{
    add:function(m){
        this.toDoList.push(m);
    },
    del:function(idx){
        this.toDoList.splice(idx,1);
    }
}
}
</script>

<style>

</style>