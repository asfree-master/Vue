
<script>
import Vue from 'vue';
var eventBus = new Vue();
export default eventBus;
</script>

