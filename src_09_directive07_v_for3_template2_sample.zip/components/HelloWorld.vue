<template>
  <div class="hello">
   <h1>template태그로 그룹핑 </h1>
   <template v-if="ok">
     <h1>title</h1>
     <p>Paragraph</p>
     <p>Paragraph</p>
   </template>    
  </div>
</template>
<script>

export default {
  name:"HelloWorld",
  props:{
    msg:String
  },
  //data는 함수로 구현 
 data:function(){
   return{
     ok: true
   }
 }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
