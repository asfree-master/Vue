<template>
  <div class="hello">
    <h1>index없이 </h1>
    <ul>
      <li v-for="name in names" :key="name"> <!--:key="유일값" -->
        {{name}}
      </li>
    </ul>
    <h1>index지정 </h1>
    <ul>
      <li v-for="(name, index) in names" :key="index">
        {{index+1}}: &nbsp; {{name}}
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  props:{
    msg:String,
  },
  //data는 함수로 작성
 data: function(){
   return {
     names :["홍길동", "이순신", "유관순"]
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
