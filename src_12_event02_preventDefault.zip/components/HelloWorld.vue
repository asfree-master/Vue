<template>
  <div class="hello">
      <h1>교제정보</h1>
      <a href="http://www.daum.net" @click="x">다음-preventDefault()</a><br>
      <a href="http://www.daum.net">다음2</a>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   methods:{
       x:function(e){
           e.preventDefault();
       }
   }
}
</script>

<style>

</style>