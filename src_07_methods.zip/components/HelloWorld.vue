<template>
  <div class="hello">
    <h1>{{ usernane }}{{age}}</h1>
   정보: {{info()}}  <!-- 메소드 호출 -->
   현재시간 : {{sayEcho()}} 
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  //props:{},
  data: function(){ //로컬 상태정보저장
    return { 
      username:"홍길동",
      age:20
    }
  },
  methods:{  //methods속성정의 ,arrow함수 사용가능하지만 this사용시 undifined됨
    sayEcho:function(){
      console.log(new Date().toString());
      return new Date().toString();
    },
    info:function(){
      return this.username+"\t" + this.age;
    }
  }//end Method   
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
