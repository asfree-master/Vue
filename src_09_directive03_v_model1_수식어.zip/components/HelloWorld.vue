<template>
  <div class="hello">
   부모로 온 props:{{msg}}<br>
   <h4>Lazy</h4>
      <input v-model.lazy="lazy" type="text"/>
      <p><!-- lazy 수식어 : Enter후 반영됨 -->
          lazy: <strong>{{lazy}}</strong>
      </p>
  <h4>Number</h4>
      <input v-model.number="number" type="text"/>
      <p><!-- number 수식어 : 숫자입력 후 문자입력 반영안됨  -->
          number: <strong>{{number}}</strong>
      </p>
  <h4>notrim</h4>
    <input v-model="noTrim" type="text"/>
    <p>
        trim: <strong>{{noTrim}}: {{noTrim.length}}</strong>
    </p>
  <h4>trim</h4>
    <input v-model.trim="trim" type="text"/>
    <p>
        trim: <strong>{{trim}}: {{trim.length}}</strong>
    </p>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  //data옵션은 function을 사용
 data: function(){
   return {
     lazy:"",
     number:"",
     noTrim:"",
     trim:""
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color:red;
}
</style>
