<template>
  <div class="hello">
    <h1>index없이 사용</h1>
    <ul v-for="(value, key) in person" :key="key"><!-- v: value, k: key -->
      {{key}} &nbsp; {{value}}
    </ul>
    <h1>index 지정 </h1>
    <ul v-for="(value, key, index) in person" :key="index">
      {{index+1}}&nbsp; {{key}}&nbsp;{{value}}
    </ul>
   
  </div>
</template>
<script>
export default {
  name:"HelloWorld",
  props:{
    msg:String
  },
  //data는 함수로 작성
  data:function(){
    return {
      person:{
        username:"홍길동",
        age:20,
        address:"서울"
      }
    }
  }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
