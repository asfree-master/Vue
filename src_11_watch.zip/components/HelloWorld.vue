<template>
  <div class="hello">
      <h1>watch속성</h1>
      값: <input type="text" v-model="num"/>      
  </div>
</template>
<script>

export default {
data:function(){
    return { num:10}
},
//watch: 1. watch속성의 함수명은 반드시 data속성명과 일치해야 함
//2. methods 및 computed함수도 data속성이 변경되면 자동호출 되지만
//반드시 명시적으로 함수명을 지정한 경우에만 해당됨
//watch는 명시적으로 호출하지 않아도 자동으로 호출됨 
watch:{
    num:function(changeValue){//함수명과 data의 변수명이 일치되어야함.
        console.log(this.num, "\t", changeValue);
    }
}
}
</script>

<style>

</style>