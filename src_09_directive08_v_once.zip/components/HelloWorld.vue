<template>
  <div class="hello">
      기본 :<span>{{username}}</span><br>
      v-once1: <span>{{username}}</span><br>
      v-once2:<span v-once>{{username}}</span><br><!--한번 랜더링 후 결과를 저장 -->
      {{changeName()}}
  </div>
</template>

<script>
export default {
name:"HelloWorld",
props:{
    msg:String
},
data:function(){
    return {
        username:"홍길동"
    }
},
methods:{
    changeName:function(){
        this.username="이순신";
    }
}
}
</script>

<style>

</style>