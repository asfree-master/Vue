<template>
 <div>
    <div class="hello">
        <h1>{{mesg}}</h1>
    </div>
    <p>World {{mesg}}</p>
 </div>
</template>

<script>

export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data: function(){
    return {mesg:"hello World"}
  },

  //lifecycle Hook==> arrow함수 사용안됨 , this문제
  beforeCreate:function(){//data, event설정안됨
    console.log("beforeCreate", this);
  },
  created: function(){//data, event 활성화 
    console.log("created");
  },
  beforeMount: function(){
    console.log("beforeMount");
  },
  mounted: function(){ //컴포넌트, template, dom 접근 가능 
    console.log("mounted1", this.$el, this.mesg, this.$el.textContent);
    //data속성값이 변경되면 자동으로 rendering 됨
    this.mesg="happy로 변경";
    console.log("mounted2", this.mesg);
  },
  beforeUpdate:function(){
    console.log("beforeUpdate");
  },
  updated:function(){
    console.log("updated");
  },
  beforeDestroy:function(){
    console.log("beforeDestroy");
  },
  destroyed:function(){
    console.log("destroyed");
  },


}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
