<template>
  <div id="app">
    <HelloWorld/>
    <happy />
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue';
import   Happy from './components/Happy.vue';

export default {
  name: 'App',
  components: {
    HelloWorld,//HelloWorld component사용
    Happy     
  }
}
</script>

<style>
</style>
