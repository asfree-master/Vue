<template>
  <div class="happy">
      <h1>happy</h1>
  </div>
</template>

<script>
export default {
    name:"happy",
}
</script>
<style>

</style>