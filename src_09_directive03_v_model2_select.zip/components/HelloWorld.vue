<template>
  <div class="hello">
    <select v-model="mesg">
      <option>10</option>
      <option>20</option>
      <option>30</option>
      <option>40</option>
    </select>
    선택된 값 : {{mesg}}
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
 //data는 반드시 함수로 작성
 data: function(){
   return {
     mesg:20
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color:red;
}
</style>
