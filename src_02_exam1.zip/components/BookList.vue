<template>
<div class="hello">
      <h1>도서목록6권</h1>
        <ul>
        <li>
            <img src="../assets/image/a.jpg" width="100" height="100">위험한 식탁
        </li>
        <li>
            <img src="../assets/image/b.jpg" width="100" height="100">공부의 비결
        </li>
        <li>
            <img src="../assets/image/c.jpg" width="100" height="100">오메르타
        </li>
        <li>
            <img src="../assets/image/d.jpg" width="100" height="100">행복한 여행
        </li>
        <li>
            <img src="../assets/image/e.jpg" width="100" height="100">해커스토익
        </li>
        <li>
            <img src="../assets/image/f.jpg" width="100" height="100">도로 안내서
        </li>
        </ul>
    </div>
</template>

<script>
export default {
    name: "hello",
}
</script>

<style>

</style>