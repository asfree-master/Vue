<template>
  <div id="app">
      <BookList/>
  </div>
</template>

<script>
import BookList from "./components/BookList";

export default {
  name: 'App',
  components: {
    BookList,
  }
}
</script>

<style>
</style>
