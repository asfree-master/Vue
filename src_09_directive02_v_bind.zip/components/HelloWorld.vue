<template>
  <div class="hello">
   <h1>{{mesg}}</h1>
   mesg<input type="text" value="mesg"><br>
   :mesg <input type="text" :value="mesg"><br>
   v-bind:mesg<input type="text" v-bind:value="mesg"><br>

  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  //data 옵션은 반드시 함수로 작성함.
 data:function(){
   return {
     mesg:"홍길동"
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color:red;
}
</style>
