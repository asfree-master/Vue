<template>
  <div class="hello">
      <button v-on:[aaa]="handleEvent">OK-bind</button><br>
      <button @[bbb]="handleEvent">@[bbb]</button><br><!--mouseover-->
      <button v-on:click="handleEvent">Ok</button><br>
      <button @click="handleEvent">@click</button><br>
      <button @click="handleEvent2" data-my="100" data-my2='{"a":200, "b":300}'>JsonData</button>
      <button v-on:click="handleEvent2" data-my="100" data-my2='{"a":200, "b":300}'>JsonData</button>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
    data:function(){
        return {
            aaa:'click',
            bbb:'mouseover',
            ccc:'mouseleave'
        }
    },
    methods:{
        handleEvent:function(e){
            console.log(e);
        },
        handleEvent2:function (e) {
            console.log(e.target.dataset.my);
            var x= JSON.parse(e.target.dataset.my2);
            console.log(x.a, x.b);
        }
    }
}
</script>

<style>

</style>