<template>
  <div class="hello">
      <button v-on:click="handleEvent">OK</button> <br>
     <button @click="handleEvent">@clickOk</button><br>
     <button v-on:click="handleEvent2" data-my="100" data-my2='{"a":"홍길동", "b":"20"}'>JsonData</button><br>
     <button @click="num++">num++</button><button @click="num--">num--</button><br>
     <button v-on:click="num++">num++</button><button @click="num--">num--</button><br>
     <button v-on:click="xxx('홍길동')">xxx</button><br>
     <button v-on:click="xxx2('홍길동',$event)">xxx2</button><br>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
    data: function(){
        return { num:0 }
    },
    methods:{
        xxx2:function(data, event){
            console.log(data,"\t",event);
        },
        xxx:function(e){
            console.log("xxx===",e);
        },
        handleEvent:function(e){
            console.log("handleEvent===",e);
        },
        handleEvent2:function(e){
            //console.log("handleEvent2======", e);
            console.log( e.target.dataset.my);
            var x= JSON.parse(e.target.dataset.my2);//data-제외접근
            console.log(x);
            console.log(x.a, x.b);
        }
    },
watch:{
    num:function(){//data와 동일
        console.log(this.num);
    }
}
}
</script>

<style>

</style>