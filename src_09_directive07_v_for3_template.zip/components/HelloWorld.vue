<template>
  <div class="hello">
   <h1>1.기본 </h1>
      <div v-for="(name, index) in names" :key="index+10" id="01">
        {{name}}님
      </div>
    <h2>2. div 태그로 그룹핑: div태그가 흔적으로 남음 </h2>
      <div v-for="(name, index) in names" :key="index+100" id=02>
        <span>{{name}}</span><span>님</span><br>
      </div>
    <h2>3. template태그로 그룹핑: template태그가 흔적으로 안남음 </h2>
    <template v-for="(name, index) in names" id="03"><!--dom에 남지 않으므로 :key지정필요없음-->
      <span :key="index+20"><!--tempate에 들어가는 태그에 유일한 값지정-->
        {{name}}
      </span>
      <span :key="index+1">님 </span><br :key="index+1000">
    </template>
    
  </div>
</template>
<script>

export default {
  name:"HelloWorld",
  props:{
    msg:String
  },
  //data는 함수로 구현 
  data:function(){
      return{
        names:["홍길동", "이순신", "유관순"]
      }
  }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
