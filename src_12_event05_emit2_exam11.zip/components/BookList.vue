<template>
  <div class="hello">
      <ul>
          <li v-for="(book, index) in bookList" :key="index">
          <a v-on:click="x">
           <img :src="require(`../assets/image/${book.img}.jpg`)"
            width="100" height="100" :data-xxx="book.name"
           />   
          </a>
          {{book.name}}
          </li>
      </ul>
  </div>
</template>

<script>
export default {
name: "HelloWorld",
props:{
    bookList:Array
},
methods:{
    x:function(e){
       // console.log(e);
        this.$emit("xyz", e.target.dataset.xxx);
    }
}
}
</script>

<style>

</style>