<template>
  <div class="app">
  <h1>도서목록{{list.length}}권</h1>
  선택된 도서:<input type="text" :value="bookName"><br>
    <BookList :bookList="list" v-on:xyz="y"/><!--자식에게 BookList란 이름으로 전달-->
  </div>
</template>

<script>
import BookList from "./components/BookList.vue"
export default {
  name: 'App',
 components:{
   BookList
 },
 data:function(){
   return{
     list:[
       {id:'p01', name:"위험한 식탁", price:2000, date:'20170401', img:'a'},
       {id:'p02', name:"공부의 비결", price:3000, date:'20170402', img:'b'},
       {id:'p03', name:"오메르타", price:4000, date:'20170403', img:'c'},
       {id:'p04', name:"행복한 여행", price:5000, date:'20170404', img:'d'},
       {id:'p05', name:"해커스 토익", price:6000, date:'20170405', img:'e'},
       {id:'p06', name:"도로 안내서", price:7000, date:'20170406', img:'f'},
     ],
     bookName:""
   }
 },
  methods:{
    y:function(x){
      console.log(x);
      this.bookName= x;
    }
  }
}


</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
