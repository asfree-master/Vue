<template>
  <div class="hello">
    <h1>자식에서 부모에게 이벤트 발생하여 데이터 전달</h1>
    <button v-on:click="x">부모에게 요청 </button><br>
    <button v-on:click="x2">부모에게 요청2</button><br>
    <button v-on:click="x3">부모에게 요청2</button><br>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   methods:{
    x:function(){
        //부모에게 xyz이벤트 발신
        console.log(this);
        this.$emit("xyz");//xyz이 됨 
    },
    x2:function(){
        console.log(this);
        this.$emit("xyz2", 100, "홍길동");//xyz2 이됨
    },
    x3:function(){
        console.log(this);
        this.$emit("xyz3", 1,2,3,4);//xyz2 이됨
    }
   }
}
</script>

<style>

</style>