<template>
  <div class="app">
   
    <HelloWorld v-on:xyz="y" v-on:xyz2="y2" v-on:xyz3="y3"/>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld.vue"

export default {
  name: 'App',
 components:{
   HelloWorld
 },
 methods:{
   y:function(){
     console.log("y");
   },
   y2:function(v, v2){
     console.log(v, v2);
   },
   y3:function(v, v2, v3, v4){
     console.log(v, v2, v3, v4);
   },
 }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
