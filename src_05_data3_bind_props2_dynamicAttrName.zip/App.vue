<template>
  <div id="app">
 <!-- 케밥표기법->카멜표기로 수신, 
 상태값의 전달
 부모 :속성명=값 또는 v-bind:속성명=값사용 
  v-bind:[속성명]=값 사용
 -->
 <HelloWorld v-bind:[attributeName]="x" v-bind:age="y"/>
 <!-- <HelloWorld v-bind:username="x" v-bind:age="y" /> -->
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue';
//import {Person}from './components/Person';

export default {
  name: 'App',
  components: {
    HelloWorld
  },
  //상태를 저장하는 data옵션은 반드시 함수로 작성한다.
  data:()=>{
    return {
      x:"강감찬",
      y:20,
      attributeName:"username"  //username을 속성으로 사용
    }
  }


}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
