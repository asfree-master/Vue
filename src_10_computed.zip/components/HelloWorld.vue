<template>
  <div class="hello">
      num값:{{num}}<br>
      {{xxx()}}{{xxx()}}
      {{yyy}}{{yyy}}    <!--computed 함수: 속성명으로 호출 -->
  </div>
</template>
<script>
export default {
data:function(){
    return{
        num:10
    }
},
//methods함수는 기본적으로 매번 호출됨
methods:{
    xxx:function(){
        console.log("xxx호출됨");
    }
},
//computed함수는 기본적으로 한번만 호출됨(캐싱)
//하지만 data속성값이 변경되면 매번 호출됨
computed:{
    yyy:function(){
        console.log("yyy호출됨");
        return "";
    }
}
}
</script>

<style>

</style>