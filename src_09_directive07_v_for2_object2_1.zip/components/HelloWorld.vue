<template>
  <div class="hello">
   과일 선택 :
   <select v-model="selectedFruit"><!--: value의 값을 사용 -->
     <option disabled selected>과일을 선택하세요</option>
     <option v-for="(value, key, index) in fruits" :key="index" :value="key">{{value}}</option>
   </select>
   <br>
   선택된 과일: {{selectedFruit}}
  </div>
</template>
<script>
export default {
  name:"HelloWorld",
  props:{
    msg:String
  },
  data:function(){
    return {
      fruits:{
        apple:"사과",
        banana:"바나나",
        melon:"멜론"
      },
      selectedFruit:"banana"
    }
    
  }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
