<template>
  <div class="hello">
      <h1>2.이벤트전파방지 stopPropagation</h1>
     <div style="background-color:yellow" v-on:click="aaa">
        aaa
        <div style="background-color:green" v-on:click="bbb">
            bbb
        </div>
     </div>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   methods:{
       aaa:function(e){
           console.log("aaa",e);
       },
       bbb:function(e){
           console.log("bbb",e);
          // e.stopPropagation();
       }
   }
}
</script>

<style>

</style>