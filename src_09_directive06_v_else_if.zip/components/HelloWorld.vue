<template>
  <div class="hello">
    점수: <input type="text" v-model.number="grade"/>
    <p v-if="grade >90">A학점</p>
    <p v-else-if="grade >80">B학점</p>
    <p v-else-if="grade >70">C학점</p>
    <p v-else>F학점</p>
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
  props:{
    msg:String,
  },
  //data는 함수로 작성
  data: function(){
    return {
      grade: 50
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
