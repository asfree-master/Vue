<template>
  <div class="hello">
    <h1>{{ username }}{{age}}</h1>
   정보: {{info()}}  <!-- 메소드 호출 --><br>
   현재시간 : {{sayEcho()}} <br>
   arrow: {{my()}}

  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  //props:{},
 data: function(){
   return {
     username:"홍길동",
     age:20
   }
 },
 methods:{
   //arrow사용
   sayEcho:()=>{
     console.log(new Date().toString());
     return new Date().toString();
   },
   info:function(){
     console.log("info>>", this);
     return this.username+"\t" +this.age;
   },
   //arrow
   my:()=>{
     console.log("my>>", this);
     return "my>>"+this;
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
