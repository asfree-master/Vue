<template>
  <div class="app">
   <h1>life Cycle Hook</h1>
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
import HelloWorld from "./components/HelloWorld.vue";
export default {
  name: 'App',
  components: {
    HelloWorld
  },
  data: function(){
    return {mesg:"Hello World2"}
  },
   //lifeCycle hook=> arrow함수 사용 안됨 , this문제
  beforeCreate:function(){
    console.log("app.beforeCreate", this);
  },
  created:function(){
    console.log("app.created");
  },
  beforeMount:function(){
    console.log("app.beforeMount");
  },
  mounted:function(){
    console.log("app.mounted1", this.$el, this.mesg, this.$el.textContent);
    //data속성이 변경되면 자동으로 rendering됨
    this.mesg="happy로 변경";
    console.log("app.mounted2", this.mesg);
  },
  beforeUpdate:function(){
    console.log("app.beforeUpdate", this);
  },
  updated:function(){
    console.log("app.updated", this);
  },
  beforeDestroy:function(){
    console.log("app.beforeDestroy", this);
  },
  destroyed:function(){
    console.log("app.destroyed", this);
  },
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
