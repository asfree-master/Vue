<template>
<div>
  <div class="hello">
      <p>{{mesg}}</p>
  </div>
  <p>World{{mesg}}</p>
</div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props: {
    msg: String
  },
  data: function(){
    return {mesg:"hello World"}
  },
  //lifeCycle hook=> arrow함수 사용 안됨 , this문제
  beforeCreate:function(){
    console.log("HelloWorld.beforeCreate", this);
  },
  created:function(){
    console.log("HelloWorld.created");
  },
  beforeMount:function(){
    console.log("HelloWorld.beforeMount");
  },
  mounted:function(){
    console.log("HelloWorld.mounted1", this.$el, this.mesg, this.$el.textContent);
    //data속성이 변경되면 자동으로 rendering됨
    this.mesg="happy로 변경";
    console.log("HelloWorld.mounted2", this.mesg);
  },
  beforeUpdate:function(){
    console.log("HelloWorld.beforeUpdate", this);
  },
  updated:function(){
    console.log("HelloWorld.updated", this);
  },
  beforeDestroy:function(){
    console.log("HelloWorld.beforeDestroy", this);
  },
  destroyed:function(){
    console.log("HelloWorld.destroyed", this);
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
