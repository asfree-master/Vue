<template>
  <div id="hello">
     <h1>도서목록 {{bookList.length}}</h1>
     <ul>
        <li v-for="book in bookList" v-bind:key="book.name" >
         <img :src="require(`../assets/image/${book.img}.jpg`)">
         <!-- <img :src="require(`@/assets/image/${book.img}.jpg`)"> -->
          <!-- backtick사용 -->          
        {{book.name}}{{book.img}}
        </li>
    </ul>   
  </div>   
</template>
<script>
export default {
    name: "BookList",
    props:{
        bookList:Array,
    }
}
</script>
<style>

</style>