<template>
  <div id="app">
   <HelloWorld msg="안녕하세요"><!--주의-->
     <!--slot영역 -->
      <div>
          아름다운 밤입니다..
      </div>
     <!--slot영역 -->
   </HelloWorld><!--주의 -->
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    HelloWorld //HelloWorld component사용
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
