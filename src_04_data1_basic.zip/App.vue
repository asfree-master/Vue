<template>
  <div id="app">
   이름:{{x}}<br>
   나이:{{y}}<br>
    <HelloWorld username="홍길동" age="20"/>
  </div>
</template>

<script>
import HelloWorld from './components/HelloWorld.vue'

export default {
  name: 'App',
  components: {
    HelloWorld
  },
  //상태를 저장하는 data옵션은 반드시 함수로 작성한다.
  data:function(){
    return { x:"홍길동", y:"40"}
  }
  // data: ()=>{ return{
  //     x:"홍길동",
  //     y:"40",
  //   }    
  // }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
