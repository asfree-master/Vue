<template>
  <div class="hello">
      <h1>교제정보</h1>
      <div v-for="(book,idx) in bookList" :key="idx">
          <input type="checkbox" v-model="books" :value="book.name">
          {{book.name}}<span>{{book.price}}</span>
          <button v-on:click="del" :data-idx="idx">삭제</button>
      </div>
      <br>
      <button v-on:click="delAll">전체삭제</button>
      
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   data:function(){
     return{
         bookList:[
             {name:"자바의 정석", price:2000},
             {name:"jsp의 정석", price:3000},
             {name:"Spring의 정석", price:4000},
             {name:"jQuery의 정석", price:5000},
             {name:"Angular의 정석", price:6000},
         ],
         books:[]
     }
   },
   methods:{
       del:function (e) {
           var delIndex= e.target.dataset.idx;
           console.log(this.books);
           this.bookList.splice(delIndex,1);           
       },
       delAll:function () {
           var xx= this.bookList;
           this.books.map(function (ele, idx) {//이름과 번호
               console.log("delAll",idx);
               xx.map(function(e, i){
                   if(e.name==ele){
                       xx.splice(i,1);
                   }
               })
           })           
       }
   }
}
</script>

<style>

</style>