<template>
  <div class="hello">
   과일 선택 :
   <select v-model="result">
     <option disabled selected>과일을 선택하세요</option>
     <option v-for="(value, key, index) in fruits" :key="index" :value="value">{{value}}</option>
   </select>
  </div>
</template>
<script>
export default {
  name:"HelloWorld",
  props:{
    msg:String
  },
  data:function(){
    return {
      fruits:{
        apple:"사과",
        banana:"바나나",
        melone:"멜론"
      },
      result:""
    }
  }
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
span{
  color:red;
}
</style>
