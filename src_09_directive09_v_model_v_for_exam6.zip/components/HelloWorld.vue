<template>
  <div class="hello">
      <h1>교재정보</h1>
    <div v-for="(book, index) in bookList" :key="index">
        <input type="checkbox" v-model="books" :value="book"/>{{book.name}}<span>{{book.price}}</span>
    </div>
    <hr>
    선택교재:
    <div v-for="(book, index) in books" :key="index+100">
        {{book.name}}       
    </div><br>
   총합:{{total}}
  </div>
</template>

<script>
export default {
name:"HelloWorld",
props:{
    msg:String
},
data:function(){
    return {
        bookList:[
            {name:"자바의 정석", price:2000},
            {name:"JSP의 정석", price:3000},
            {name:"Spring의 정석", price:4000},
            {name:"JQuery의 정석", price:5000},
            {name:"Angluar의 정석", price:6000},
        ],
        books:[],
        total:0
    }
},
watch:{
    books:function(){
        var xxx=0;
        var kkk= this.books;
        kkk.map(function(element, index){
            console.log("watch 실행됨", index, element.name, element.price);
            xxx+= Number.parseInt(element.price);
        });
        this.total=xxx;
    }
}
}
</script>

<style>

</style>