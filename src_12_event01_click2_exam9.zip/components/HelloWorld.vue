<template>
  <div class="hello">
      <h1>이벤트실습1</h1>
        가격:<input type="text" v-model="price"><br>
        갯수:
        <select v-on:change="sum()" v-model="quantity">
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="40">40</option>
        </select><br>
        결과 : {{total}}
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   data:function(){
       return {
          price:'',
          quantity:'',
          total:''
       }
   },
   methods:{
       sum:function(){
           this.total=Number.parseInt(this.price)* Number.parseInt(this.quantity);
       }
   }
}
</script>

<style>

</style>