<template>
  <div class="hello">
    <h1>과일을 선택하세요</h1>
      <input type="checkbox" v-model="fruits" value="사과">사과<br>
      <input type="checkbox" v-model="fruits" value="배">배<br>
      <input type="checkbox" v-model="fruits" value="바나나">바나나<br>
      <input type="checkbox" v-model="fruits" value="수박">수박<br>
    선택된 과일은 다음과 같다.  : {{fruits}}
  </div>
</template>
<script>
export default {
  name: 'HelloWorld',
 //data는 반드시 함수로 작성
 data: function(){
   return {
     fruits:[]
   }
 }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1{
  color:red;
}
</style>
