<template>

  <div class="hello">
    {{msg}}<br>
   <p v-if="3>1">Hello1</p>
   <p v-show="num >=num2">Hello2</p>
   <p v-if="num<num2">Hello3</p>
   <p v-show="(num > num2)&& (3==3) ">Hello4</p>
   <p v-show="num < num2 || 3==3"> Hello5</p>
     </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  props:{
    msg:String
  },
  //data옵션은 반드시 함수로 작성함.
  data:function(){
    return {
      num:10,
      num2:5
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
