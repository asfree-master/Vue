<template>
  <div class="hello">
      <h1>1.once 이벤트 수식어 .once</h1>
        <button v-on:click="x">ok</button><br>
        <button v-on:click.once="y">ok.once</button><br>
    <h1>2.preventDefault이벤트수식어</h1>
        <a href="http://www.daum.net" v-on:click="y">daum.net-preventDefault</a><br>
        <a href="http://www.daum.net" v-on:click="y2">daum.net</a><br>
        <a href="http://www.daum.net" v-on:click.prevent="y2">click.prevent</a><br>
    <h1>3.stop 이벤트 수식어(stopPropagation)</h1>
        <div style="background-color:yello" v-on:click="aaa">
            aaa
            <div style="background-color:green" v-on:click.stop="bbb">
                bbb
            </div>
        </div>
    <h1>4.enter 이벤트 수식어</h1>
    <input type="text" v-on:keyup="xzy"><br>
    <input type="text" v-on:keyup.enter="xzy"><br><!--enter시 동작 -->
    <h1>5.ctrl 이벤트 수식어</h1>
    <input type="text" v-on:keyup.ctrl.enter="xzy"><br>
    <input type="text" v-on:keyup.ctrl.up="xzy"><br>
  </div>
</template>
<script>
export default {
    name:"HelloWorld",
   methods:{
       x:function(){
           console.log("x");
       },
       y:function(e){
           e.preventDefault();
           console.log("y===",e);
       },
       y2:function(){
           console.log("y2실행");
       },
       aaa:function(e){
           console.log("aaa", e);
       },
       bbb:function(e){
           console.log("bbb", e);
       },
       xzy:function(e){
           console.log("xyz", e);
       }

   }
}
</script>

<style>

</style>